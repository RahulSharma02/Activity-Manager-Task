


var task = "";

var status = "";

var priority = "";


var date = "";

var len = [];
var toUpdate = 0;
var cdat ="";
var arr = [];
// to print and get date

// v

// getData();
//   // printData();

var today = new Date();
      var dd = today.getDate();
      var mm = today.getMonth() + 1; //January is 0!   
         var yyyy = today.getFullYear();
      if (dd < 10) {
        dd = "0" + dd;
      }
      if (mm < 10) {
        mm = "0" + mm;
      }
      var today = yyyy + "-" + mm + "-" + dd;      var x = Date.now();
      var a = new Date(x);
      var y = a.getFullYear();
      var m = "0" + (a.getMonth() + 1);
      var d = "0" + a.getDate();
      var date1 = y + "-" + m + "-" + dd;      
      document.getElementById("date").value = date1;   
         console.log(date1);

// getData();

$(document).ready(function() {


  // user = localStorage.getItem("array"),
  // recData = JSON.parse(user);




  $("#Add").click(function() {
    task = $("#task").val();

    status = $("#status")
      .find(":selected")
      .text();

    priority = $("#priority")
      .find(":selected")
      .text();
  date =$("#date").val();

      // document.getElementById("date").value = date1;  
      if (task != "" && status != "" && priority != "") {
    
        arr.push({
      task: task,
      date: date,
      status: status,
      priority: priority
    });

    localStorage.setItem("array", JSON.stringify(arr));

  
     printData();
   
  } 

  else {
    alert("fill all the details first");
}
document.getElementById("task").value="";

  }); // click ends here

});    // jquery ends here


  function printData(){

    var str = localStorage.getItem("array");
    arr = JSON.parse(str);

    var data1 =  "<tr><td><b>Task</b></td><td><b>Date</b></td><td><b>Status</b></td><td><b>Priority</b></td><td><b>Delete</b></td><td><b>Edit</b></td></tr>";
    // console.log("i wii be used for delete fn im in getdata",len)

  arr.forEach(function(key, value) {
      console.log("hi iam checking array value",key.date)
     if(key.date==date1){
      /* iterate through array or object */
      data1 += "<tr>";

      data1 += "<td>" + key.task + "</td>";
      data1 += "<td>" + key.date + "</td>";
      data1 += "<td>" + key.status + "</td>";
      data1 += "<td>" + key.priority + "</td>";
      data1 +=
        `<td>` +
        `<button id="btn1"  class="btn btn-danger mx-1 pb-2" onclick =deleteItem(`+
        value +
        `)>Delete</button>` +
        `</td>`;

      data1 +=
        `<td>` +
        `<button id="btn2" class="btn btn-warning mx-1 pt-2" onclick="Edit
               (` +
        value +
        `)">Edit</button>` +
        `</td>`;
    }
 
    });
    $(".table1").html(data1);
  
  }

  



  // function to send data to storage




 // function to print values from the local storage

  
  
  // function to delete items
  function deleteItem (value){
    console.log("m testing forvalue passed",value);
    arr.splice(value,1);
    localStorage.setItem("array", JSON.stringify(arr));

    printData();
    
      }
    

// // function to edit 
function Edit(item) {
  toUpdate = item;
 {
  document.getElementById("task").value = arr[item].task;
  document.getElementById("status").value = arr[item].status;
  document.getElementById("priority").value = arr[item].priority;
  document.getElementById("date").value = arr[item].date;
  //item1 = item;
  //console.log(arr, "ggggg");
  // }
}        
}

$(document).ready(()=>

$("#show").click(()=>

update()
)
)





function update() {           
  console.log("im inside update fn")
   var data = {};
  data["task"] = document.getElementById("task").value;
  data["status"] = document.getElementById("status").value;
  data["priority"] = document.getElementById("priority").value;
  data["date"] = document.getElementById("date").value;
  arr.splice(toUpdate, 1, data);
  localStorage.setItem("array", JSON.stringify(arr));
  printData();     


   }



// fUNCTION TO HIDE DIV



$(document).ready(()=>

$("#link2").click(()=>
pHide()
)
)


// function to show and hide div2

$(document).ready(function(value){
  $("#div2").toggle();

  $("#link1").click(function(){
    $("#div2").toggle();

    return false;
  });
   

  $("#btn2").click(function(){
    $("#div2").toggle();

    return false;
  });
   

});





  // getData();
printData();